/* ------------------------------ TASK 3 -----------------------------------
Parašykite JS kodą, kuris leis vartotojui paspaudus ant mygtuko "Show users"
pamatyti vartotojus iš Github API (endpoint'as pateiktas žemiau).

Paspaudus mygtuką "Show users":
1. Pateikiamas informacijos atvaizdavimas <div id="output"></div> bloke
1.1. Infrmacija, kuri pateikiama: "login" ir "avatar_url" reikšmės (kortelėje)
2. Žinutė "Press "Show Users" button to see users" turi išnykti;
"
Pastaba: Informacija apie user'į (jo kortelė) bei turi turėti bent minimalų stilių;
-------------------------------------------------------------------------- */

const ENDPOINT = 'https://api.github.com/users';
const output = document.querySelector("#output");
const messagePlaceholder = document.querySelector("#message");
const btn = document.querySelector("#btn");

async function getMessages() {
  const response = await fetch("https://api.github.com/users");
  const messages = response.json();
  return messages;
}

async function showMessages() {
const messages = await getMessages();

messagePlaceholder.remove();

messages.forEach((message) => {
const messageHolder = document.createElement("div");
output.append(messageHolder);
messageHolder.classList.add("messageHolder");

const title = document.createElement("p");
messageHolder.append(title);
title.classList.add("title");
title.textContent = `Title: ${message.title}`;

const body = document.createElement("p");
messageHolder.append(body);
body.classList.add("body");
body.textContent = `Body: ${message.body}`;
  });
}

btn.addEventListener("click", showMessages);